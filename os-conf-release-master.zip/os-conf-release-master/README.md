Few OS customizations as a BOSH release:

- customize login banner text (`login_banner`)
- change TCP keepalive kernel args (`tcp_keepalive`)

See `manifests/` for examples.
